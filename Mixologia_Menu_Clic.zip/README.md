# Mixología Tropical

Página web de coctelería lista para publicar en **GitHub Pages**.

## 🚀 Estructura
- index.html (contenido principal)
- style.css (diseño tropical responsive)
- img/ (carpeta de imágenes con portada, recetas y técnicas)

## 📌 Pasos para publicar en GitHub Pages
1. Sube todos estos archivos a un repositorio en tu GitHub (ejemplo: Mixologia).
2. Entra a Settings > Pages > selecciona la rama `main` y carpeta `/root`.
3. Guarda los cambios y espera unos segundos.
4. Accede a tu web en: `https://TUUSUARIO.github.io/Mixologia/`
